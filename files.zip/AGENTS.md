# AGENTS.md — Архитектура и конфигурация агентов OPENCLAW

> Версия: 1.1  
> Организация: Сбербанк  
> Платформа: DropApp Cluster  
> LLM: MIP — Qwen3.5  
> Обновлено: 2026-05

---

## 1. Инфраструктурная схема

OPENCLAW развёрнут в кластере **DropApp** Сбербанка. Все LLM-вызовы идут
через внутреннюю платформу **MIP (Managed Inference Platform)** на модель **Qwen3.5**.
Внешние LLM-провайдеры не используются.

```
┌─────────────────────── DropApp Cluster ───────────────────────┐
│                                                                │
│   Пользователь → Orchestrator Agent                           │
│                       ↓                                       │
│              ┌─────────────────┐                              │
│              │   PM Agent      │  ← MIP / Qwen3.5             │
│              │   Auth Agent    │  ← per-session tokens        │
│              │ Skill Dispatcher│  ← skills/ registry          │
│              │  Output Agent   │  ← форматирование            │
│              └─────────────────┘                              │
│                       ↓                                       │
│         Внутренние API Сбера / Пользовательские скилы         │
│                                                               │
└───────────────────────────────────────────────────────────────┘
         ↕ только авторизованные маршруты
   Закрытые системы (mapp.sberbank.ru и др.) — НЕ доступны
   без явно настроенного скила с механизмом аутентификации
```

---

## 2. LLM: MIP и Qwen3.5

Все запросы к языковой модели проходят через **MIP API** — внутренний endpoint Сбера.

```yaml
llm:
  provider: "MIP"
  model: "Qwen3.5"
  endpoint: "${MIP_ENDPOINT}"        # внутренний endpoint DropApp
  api_key_env: "MIP_API_KEY"         # из secrets кластера
  max_tokens: 8192
  temperature: 0.3                    # низкая для PM-задач, требующих точности
  timeout: 60s
  retry_on_timeout: 2
```

**Важно:** OPENCLAW не обращается к OpenAI, Anthropic API или любым внешним LLM.
Все вызовы остаются внутри периметра Сбера.

---

## 3. Описание агентов

### 3.1 Orchestrator Agent

**Роль:** Точка входа. Анализирует запрос, определяет тип задачи,
маршрутизирует к нужному агенту или цепочке.

**Логика маршрутизации:**

| Тип запроса | Маршрут |
|---|---|
| Новая задача без спецификации | PM Agent |
| Вызов авторизованного скила | Auth Agent → Skill Dispatcher |
| Генерация документа | PM Agent → Output Agent |
| Создание нового скила | PM Agent → Skill Builder |
| Обращение к закрытой системе | Отказ + предложение создать скил |
| Административный запрос | Auth Agent |

```yaml
orchestrator:
  max_hops: 5
  timeout_per_agent: 30s
  fallback: "pm_agent"
  log_routing: true
  closed_systems_list: "TOOLS.md#закрытые-системы"
```

---

### 3.2 PM Agent

**Роль:** Менеджер проектов. Собирает требования, формирует бриф,
согласует до начала выполнения. Также ведёт сессию создания нового скила.

```yaml
pm_agent:
  llm: "mip/qwen3.5"
  max_clarification_rounds: 3
  questions_per_round: 5
  brief_confirmation: required
  skill_creation_mode: enabled      # помогает создавать скилы пользователям
```

---

### 3.3 Auth Agent

**Роль:** Управление токенами per-session. Проверяет роль перед выдачей токена.
Не хранит токены между сессиями.

```yaml
auth_agent:
  token_min_length: 16
  token_max_attempts: 3
  session_ttl: 3600s
  mask_pattern: "***-{last4}"
  token_scopes:
    - tracker_read
    - tracker_write
    - notify_send
    - docs_write
    - custom_skill               # scope для пользовательских скилов
```

---

### 3.4 Skill Dispatcher

**Роль:** Вызов скилов из реестра. Поддерживает как системные скилы,
так и пользовательские скилы из `skills/user/`.

```yaml
skill_dispatcher:
  registry_system: "skills/system/"     # системные скилы
  registry_user: "skills/user/"         # пользовательские скилы
  auth_check: strict
  retry_on_error: 2
  timeout: 60s
  sandbox_user_skills: true             # пользовательские скилы в изолированной среде
```

---

### 3.5 Skill Builder Agent *(новый)*

**Роль:** Помогает пользователям создавать собственные скилы.
Проводит через структурированный процесс: цель → endpoint → аутентификация →
параметры → тест → регистрация в `skills/user/`.

```yaml
skill_builder:
  llm: "mip/qwen3.5"
  output_path: "skills/user/"
  template: "SKILL_TEMPLATE_V1"
  validation: true                      # проверяет синтаксис SKILL.md перед сохранением
  closed_systems_awareness: true        # знает про закрытые системы Сбера
```

---

### 3.6 Output Agent

**Роль:** Форматирование и доставка результата.

```yaml
output_agent:
  default_format: "markdown"
  formats_supported: [markdown, plain_text, structured_json]
  language_default: "ru"
  redact_tokens: true
```

---

## 4. Закрытые системы Сбера

Ряд внутренних систем недоступен OPENCLAW без специальной настройки:

| Система | Причина недоступности | Возможность скила |
|---|---|---|
| mapp.sberbank.ru | Нет открытого API, нужен client certificate | Да, если пользователь предоставит механизм |
| Системы за VPN-периметром DropApp | Нет маршрута из кластера | Уточнить у команды DropApp |
| Системы с mTLS | Требуют клиентский сертификат | Да, если сертификат передан в конфиг скила |
| Legacy-системы без API | Только UI-доступ | Нет (без WebDriver/RPA интеграции) |

**Поведение агента при обращении к закрытой системе:**
```
Система [название] недоступна: [причина].
Если знаешь endpoint и способ аутентификации — я помогу создать скил.
Начнём?
```

---

## 5. Цепочки агентов

### Новая задача
```
Пользователь → Orchestrator → PM Agent → [Auth Agent → Skill Dispatcher]
→ Output Agent → Пользователь
```

### Создание пользовательского скила
```
Пользователь → Orchestrator → PM Agent → Skill Builder
→ [тест вызова] → регистрация в skills/user/ → Пользователь
```

### Закрытая система — пользователь знает как
```
Пользователь → Orchestrator → Skill Builder (режим closed_system)
→ [пользователь передаёт endpoint + auth-механизм]
→ SKILL.md создаётся в skills/user/ → регистрация → Пользователь
```
