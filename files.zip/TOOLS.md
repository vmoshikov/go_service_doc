# TOOLS.md — Реестр инструментов и скилов OPENCLAW

> Версия: 1.1  
> Организация: Сбербанк · DropApp Cluster  
> LLM: MIP — Qwen3.5  
> Обновлено: 2026-05

---

## 1. Принципы работы с инструментами

- Агент использует скилы из двух реестров: `skills/system/` и `skills/user/`
- **Любой пользователь может создать свой скил** — агент помогает с этим
- Скилы с флагом `auth: true` запрашивают токен перед выполнением
- Пользовательские скилы выполняются в изолированной sandbox-среде
- К закрытым системам без API или без сертификата — доступ невозможен без явной настройки в скиле

---

## 2. Встроенные PM-инструменты (без авторизации)

### `tool:brief_builder`

Структурирование задачи через уточняющие вопросы → генерация брифа.

**Шаблон BRIEF_V1:**
```markdown
## Бриф задачи

**Название:** {title}
**Цель:** {goal}
**Ожидаемый результат:** {deliverable}
**Контекст:** {context}
**Заказчик:** {stakeholder_owner}
**Исполнитель(и):** {assignees}
**Согласующий:** {approver}
**Срок:** {deadline}
**Приоритет:** {priority}
**Ограничения:** {constraints}
**Зависимости:** {dependencies}
**Скилы для выполнения:** {skills_required}
**Формат результата:** {output_format}
```

---

### `tool:risk_matrix`

Оценка рисков по осям вероятность × влияние. Формирует таблицу рисков с митигацией.

---

### `tool:document_generator`

Генерация внутренних документов из брифа.

| Тип | Ключ |
|---|---|
| Техническое задание | `tz` |
| Протокол встречи | `meeting_notes` |
| Статусный отчёт | `status_report` |
| Постановка задачи | `task_description` |
| Матрица RACI | `raci` |

---

## 3. Авторизованные системные скилы

### `tool:tracker_read` / `tool:tracker_write`

```yaml
auth: true
token_scope: tracker_read | tracker_write
endpoint: "${INTERNAL_TRACKER_URL}/api/v1/tasks"
```

### `tool:notify_send`

```yaml
auth: true
token_scope: notify_send
endpoint: "${INTERNAL_NOTIFY_URL}/api/v1/messages"
```
Обязательное подтверждение перед отправкой: агент показывает превью и ждёт «да».

### `tool:docs_write`

```yaml
auth: true
token_scope: docs_write
endpoint: "${INTERNAL_DOCS_URL}/api/v1/documents"
```

---

## 4. Пользовательские скилы (User Skills)

### Кто может создавать

**Любой пользователь** — вне зависимости от роли (Viewer / Member / Manager / Admin).
Скил создаётся в `skills/user/{username}/` и доступен его создателю.
Поделиться скилом с командой — через заявку к Admin.

---

### Как создать скил: диалог с агентом

Пользователь пишет одно из:
- «Хочу создать скил для [системы]»
- «Помоги подключить [API/сервис]»
- «Знаю как обратиться к [системе] — сделаем скил?»

Агент запускает **Skill Builder** и проводит через вопросы:

```
1. Что делает скил? (цель, ожидаемый результат)
2. Endpoint: URL + HTTP-метод
3. Аутентификация: токен / Basic / mTLS / сертификат / другое
4. Параметры запроса (заголовки, body, query params)
5. Формат ответа (что вернуть пользователю)
6. Нужна ли авторизация через Auth Agent?
7. Тест: попробуем вызвать прямо сейчас?
```

---

### Шаблон SKILL.md для пользовательского скила

```yaml
---
name: my_skill_name
description: |
  Краткое описание — что делает скил и когда его использовать.
  Триггерные фразы: [список]
author: "user_id"
created_at: "2026-05-21"
version: "1.0"
auth_required: true | false
token_scope: "custom_skill"        # если auth_required: true
sandbox: true                      # всегда true для пользовательских скилов
---

## Endpoint

method: GET | POST | PATCH | DELETE
url: "https://api.internal.sber.ru/..."
timeout: 30s

## Аутентификация

# Вариант 1 — Bearer-токен (запрашивается через Auth Agent)
auth:
  type: bearer
  header: "Authorization"
  value: "Bearer {TOKEN}"

# Вариант 2 — Basic Auth
auth:
  type: basic
  username_env: "SKILL_USER"
  password_env: "SKILL_PASS"

# Вариант 3 — Client Certificate (mTLS)
auth:
  type: mtls
  cert_path: "certs/{skill_name}.crt"
  key_path: "certs/{skill_name}.key"
  # Сертификат загружается отдельно через Admin

# Вариант 4 — Кастомный заголовок
auth:
  type: custom_header
  header: "X-Internal-Token"
  value_env: "MY_SKILL_TOKEN"

## Параметры запроса

headers:
  Content-Type: "application/json"
  X-Source: "openclaw"

body_template: |
  {
    "query": "{USER_QUERY}",
    "project_id": "{PROJECT_ID}"
  }

## Формат ответа

response_path: "data.items"        # JSON-путь к нужным данным
output_format: markdown            # как отформатировать для пользователя

## Обработка ошибок

errors:
  401: "Токен недействителен. Введите токен повторно."
  403: "Нет доступа. Проверьте права в системе."
  404: "Ресурс не найден. Уточните параметры запроса."
  500: "Сервис недоступен. Попробуйте позже."

## Тест

test_call:
  description: "Проверочный запрос с минимальными параметрами"
  params:
    query: "test"
```

---

## 5. Закрытые системы Сбера

Системы, к которым OPENCLAW **не может обратиться** без специальной настройки:

| Система | Причина | Путь к решению |
|---|---|---|
| `mapp.sberbank.ru` | Нет открытого API; требуется client certificate | Пользователь описывает endpoint + предоставляет cert → создаём скил с `auth.type: mtls` |
| Системы за внутренним VPN Сбера (не DropApp) | Нет сетевого маршрута из кластера | Уточнить у команды DropApp, нужен network policy |
| Legacy-порталы (только UI) | Нет API, только браузерный доступ | Без RPA-интеграции невозможно |
| Системы с IP-вайтлистингом | DropApp IP не в списке | Admin добавляет IP кластера в вайтлист системы |

### Поведение агента при закрытой системе

```
Я не могу обратиться к mapp.sberbank.ru напрямую:
— нет известного открытого API
— требуется клиентский сертификат

Если ты знаешь:
  • URL endpoint'а и метод запроса
  • как работает аутентификация (сертификат, токен, другое)

Я помогу создать скил. Начнём?
```

### Процесс создания скила для mTLS-системы

```
Пользователь: «Знаю как войти в mapp — есть сертификат и endpoint»

OPENCLAW:
1. Какой endpoint и метод? (URL + GET/POST)
2. Сертификат — клиентский .crt/.key или CA-сертификат?
3. Нужен ли дополнительный токен в заголовке?
4. Что должен вернуть скил пользователю?

→ Создаём SKILL.md с auth.type: mtls
→ Сертификат передаётся Admin для размещения в certs/
→ Скил регистрируется → тест → готово
```

---

## 6. Обработка ошибок инструментов

| Код | Причина | Действие агента |
|---|---|---|
| 401 | Невалидный токен | Повторный запрос (макс. 3 попытки) |
| 403 | Нет прав | Сообщить, предложить другой scope или Admin |
| 404 | Ресурс не найден | Уточнить идентификатор у пользователя |
| 429 | Rate limit | Подождать 30 сек, повторить |
| 495/496 | Ошибка сертификата (mTLS) | «Проблема с сертификатом — обратитесь к Admin» |
| 500–503 | Сервис недоступен | Уведомить, предложить retry |
| timeout | Превышен таймаут | Уведомить, предложить повторить |

---

## 7. Переменные окружения (DropApp Cluster)

```env
# MIP / LLM
MIP_ENDPOINT=https://mip.internal.sber.ru/v1
MIP_API_KEY=<из secrets кластера>

# Системные инструменты
INTERNAL_TRACKER_URL=https://tracker.internal.sber.ru
INTERNAL_NOTIFY_URL=https://notify.internal.sber.ru
INTERNAL_DOCS_URL=https://docs.internal.sber.ru

# Параметры токенов
TOKEN_MIN_LENGTH=16
SESSION_TTL=3600
MAX_TOKEN_ATTEMPTS=3

# Пути реестров скилов
SKILL_REGISTRY_SYSTEM=skills/system/
SKILL_REGISTRY_USER=skills/user/
SKILL_CERTS_PATH=certs/
```
